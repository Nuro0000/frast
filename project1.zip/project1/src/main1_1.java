public class main1_1 {
    public static void main(String args[])
    {
        Circle circle1=new Circle();
        Square square1=new Square();
        circle1.makeVisible();
        square1.makeVisible();
    }
}
