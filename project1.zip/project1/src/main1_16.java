public class main1_16 {
    public static void main(String args[])
    {
        Picture sunday=new Picture();
        sunday.draw();
        sunday.sunrise();
    }
}

