public class main1_3 {
    public static void main(String args[])
    {
        Circle circle1 = new Circle();
        circle1.makeVisible();
        circle1.slowMoveHorizontal(-70);
    }
}
