public class main1_2 {
    public static void main(String args[])
    {
        int i=0;
        Circle circle1=new Circle();
        circle1.makeVisible();
        circle1.moveDown();
        circle1.moveDown();
    }
}
